def my_middlewares(get_response):
    print('first initialization')


    def my_fun(request):
        print('this is before view')

        response = get_response(request)

        return response
    return my_fun

class sample_middleware:

    def __init__(self,get_response):
        print('This is First init function')
        self.get_response = get_response

    def __call__(self, request,*args, **kwargs):
        print("Code to be executed before view")
        response = self.get_response(request)

        print("Code to be executed after view")


        return response

class sun_middleware:

    def __init__(self,get_response):
        print('This is third initialization')
        self.get_response = get_response
    def __call__(self,request, *args, **kwargs):

        response = self.get_response(request)
